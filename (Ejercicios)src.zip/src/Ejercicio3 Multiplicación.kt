fun main() {
    val a = 10
    val b = 5

    val resultado = MultiplicarNumeros(a,b)
    println("El producto es: $resultado")
}

fun MultiplicarNumeros(x: Int, y: Int): Int {
    return x * y
}
